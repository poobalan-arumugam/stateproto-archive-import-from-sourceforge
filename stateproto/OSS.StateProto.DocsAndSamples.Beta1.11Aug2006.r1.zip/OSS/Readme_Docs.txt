Locations:

docs in Development\MurphyPA\Modelling\H2D\doc

compiled samples in Development\MurphyPA\Modelling\H2D\doc\Hsm\bin

sample source in Development\MurphyPA\Modelling\H2D\doc\Hsm\Samples

stateProto.exe in Development\MurphyPA\Modelling\H2D\doc\Hsm



Questions to murphyarum [at] gmail [.] com
or           statedriven [at] sourceforge [.] net

