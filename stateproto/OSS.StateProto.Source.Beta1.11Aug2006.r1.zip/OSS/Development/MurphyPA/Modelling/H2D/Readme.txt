Hierarchical 2-D Drawings



Build instructions:

Load H2D.sln and build.

All projects make assembly references only and build to 

..\..\..\bin\
..\..\..\bin\lib\common
..\..\..\bin\lib\stateproto
..\..\..\bin\lib\qf4net

