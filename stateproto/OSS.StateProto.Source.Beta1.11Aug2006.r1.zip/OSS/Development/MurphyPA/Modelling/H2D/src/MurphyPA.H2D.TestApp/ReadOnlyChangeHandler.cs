using System;

namespace MurphyPA.H2D.TestApp
{
	/// <summary>
	/// ReadOnlyChangeHandler.
	/// </summary>
	public delegate void ReadOnlyChangeHandler (IUIInterationContext context);
}
