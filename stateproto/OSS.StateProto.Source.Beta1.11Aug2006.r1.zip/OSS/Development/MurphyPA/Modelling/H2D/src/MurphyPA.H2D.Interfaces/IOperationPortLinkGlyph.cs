using System;

namespace MurphyPA.H2D.Interfaces
{
	/// <summary>
	/// Summary description for IOperationPortLink.
	/// </summary>
	public interface IOperationPortLinkGlyph : IGlyph
	{
	}
}
