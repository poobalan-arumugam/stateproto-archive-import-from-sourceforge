using System;
using System.Collections;

namespace qf4net
{
	/// <summary>
	/// Summary description for IQSupportsSubMachines.
	/// </summary>
	public interface IQSupportsSubMachines
	{
		IEnumerable SubMachines { get; } 
	}
}
