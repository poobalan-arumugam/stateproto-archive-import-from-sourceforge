using System;

namespace qf4net
{
	/// <summary>
	/// IQSimpleCommand.
	/// </summary>
	public interface IQSimpleCommand
	{
        void Execute ();
	}
}
