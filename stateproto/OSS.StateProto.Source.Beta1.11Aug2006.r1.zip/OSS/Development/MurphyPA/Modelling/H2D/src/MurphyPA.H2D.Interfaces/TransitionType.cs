using System;

namespace MurphyPA.H2D.Interfaces
{
	/// <summary>
	/// Summary description for TransitionType.
	/// </summary>
	public enum TransitionType { Normal, History, DeepHistory }
}
