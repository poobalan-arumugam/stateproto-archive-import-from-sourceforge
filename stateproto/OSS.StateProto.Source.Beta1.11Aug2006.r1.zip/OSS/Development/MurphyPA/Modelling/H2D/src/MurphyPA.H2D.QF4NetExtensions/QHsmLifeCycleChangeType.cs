using System;

namespace qf4net
{
	/// <summary>
	/// QHsmLifeCycleChangeType.
	/// </summary>
    public enum QHsmLifeCycleChangeType { Added, Removed }
}
