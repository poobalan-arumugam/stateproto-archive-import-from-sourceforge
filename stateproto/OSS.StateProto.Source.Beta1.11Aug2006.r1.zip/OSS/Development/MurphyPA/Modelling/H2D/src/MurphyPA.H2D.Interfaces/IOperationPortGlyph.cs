using System;

namespace MurphyPA.H2D.Interfaces
{
	/// <summary>
	/// Summary description for IOperationPortGlyph.
	/// </summary>
	public interface IOperationPortGlyph : IGlyph
	{
	}
}
