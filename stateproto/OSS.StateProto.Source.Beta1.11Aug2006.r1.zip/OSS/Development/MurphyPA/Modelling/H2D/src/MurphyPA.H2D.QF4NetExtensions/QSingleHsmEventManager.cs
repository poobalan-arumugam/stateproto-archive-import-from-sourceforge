using System;

namespace qf4net
{
	/// <summary>
	/// Summary description for SingleHsmEventManager.
	/// </summary>
	public class QSingleHsmEventManager : QEventManagerBase
	{
		public QSingleHsmEventManager (IQTimer timer)
			: base (timer)
		{
		}
	}
}
