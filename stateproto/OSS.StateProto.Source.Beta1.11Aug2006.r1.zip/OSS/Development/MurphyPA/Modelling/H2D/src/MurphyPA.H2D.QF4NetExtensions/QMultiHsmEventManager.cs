using System;

namespace qf4net
{
	/// <summary>
	/// Summary description for QMultiHsmEventManager.
	/// </summary>
	public class QMultiHsmEventManager : QEventManagerBase
	{
		public QMultiHsmEventManager (IQTimer timer)
			: base (timer)
		{
		}
	}
}
