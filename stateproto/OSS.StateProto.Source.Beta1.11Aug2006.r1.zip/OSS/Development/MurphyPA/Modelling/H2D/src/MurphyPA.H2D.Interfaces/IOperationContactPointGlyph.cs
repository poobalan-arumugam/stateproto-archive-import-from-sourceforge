using System;

namespace MurphyPA.H2D.Interfaces
{
	/// <summary>
	/// Summary description for IOperationContactPointGlyph.
	/// </summary>
	public interface IOperationContactPointGlyph : IGlyph
	{
	}
}
