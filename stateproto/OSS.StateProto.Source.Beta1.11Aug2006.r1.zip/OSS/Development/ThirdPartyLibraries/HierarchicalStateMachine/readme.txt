The source code in this directory is the C# port of Miro Samek's Quantum Framework including his excellent 
implementation of a hierarchical state machine. 

Please consult the application notes (pdf file) in the subfolder 'Documentation' for details about this port.

The file 'VersionHistory.html' lists the version history of the port and the changes in between versions.