using System;
using qf4net;

namespace QHsmTest
{
	public enum MyQSignals : int
	{
	   	A_Sig = QSignals.UserSig,
	   	B_Sig,
	   	C_Sig,
	   	D_Sig,
	   	E_Sig,
	   	F_Sig,
	   	G_Sig,
	   	H_Sig,
	};
}
