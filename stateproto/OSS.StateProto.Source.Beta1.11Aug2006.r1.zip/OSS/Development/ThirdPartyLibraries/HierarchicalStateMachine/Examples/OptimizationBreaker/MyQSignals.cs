using System;
using qf4net;

namespace OptimizationBreaker
{
	public enum MyQSignals : int
	{
	   	Sig1 = QSignals.UserSig,
	   	Sig2
	};
}
